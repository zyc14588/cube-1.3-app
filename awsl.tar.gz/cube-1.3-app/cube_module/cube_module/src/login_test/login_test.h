#ifndef LOGIN_TEST_H
#define LOGIN_TEST_H
 
 
int login_test_init (void * sub_proc, void * para);
int login_test_start (void * sub_proc, void * para);
#endif
