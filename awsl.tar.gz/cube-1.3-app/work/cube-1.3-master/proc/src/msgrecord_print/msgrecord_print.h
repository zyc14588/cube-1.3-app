#ifndef MSGRECORD_PRINT_H
#define MSGRECORD_PRINT_H
 
 
int msgrecord_print_init (void * sub_proc, void * para);
int msgrecord_print_start (void * sub_proc, void * para);
#endif
