#ifndef STRUCT_MANAGE_H
#define STRUCT_MANAGE_H

// plugin's init func and kickstart func
int struct_manage_init(void * sub_proc,void * para);
int struct_manage_start(void * sub_proc,void * para);

#endif
