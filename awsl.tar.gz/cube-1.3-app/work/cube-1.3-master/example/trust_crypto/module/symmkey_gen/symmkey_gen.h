#ifndef SYMMKEY_GEN_H
#define SYMMKEY_GEN_H

int symmkey_gen_init(void * sub_proc,void * para);
int symmkey_gen_start(void * sub_proc,void * para);

#endif
