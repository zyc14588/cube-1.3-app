#ifndef KEY_REQUEST1_H
#define KEY_REQUEST1_H

int key_request1_init(void * sub_proc,void * para);
int key_request1_start(void * sub_proc,void * para);

#endif
